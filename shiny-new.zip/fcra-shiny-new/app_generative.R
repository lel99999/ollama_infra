# Load necessary libraries
library(shiny)
library(DT)
library(duckdb)
library(ollamar)
library(openxlsx)
library(lubridate)  # For date handling

# Source external SQL generation function
setwd("/srv/shiny-server/apps/fcra-shiny-new/")
source("llm_functions.R")  # Update this path to your actual file

# Load saved queries function
load_saved_queries <- function() {
  if (file.exists("References/saved_queries.csv")) {
    queries <- read.csv("References/saved_queries.csv", stringsAsFactors = FALSE)
    queries$text <- gsub("^^.*?:", "", queries$text)  # Remove comments starting with #
    queries$text <- trimws(queries$text)  # Trim any leading or trailing whitespace
  } else {
    queries <- data.frame(text = character(), query = character(), stringsAsFactors = FALSE)
  }
  queries
}

# Save new query function
save_query <- function(text, query) {
  queries <- load_saved_queries()
  
  # Add "# Example:" before the actual text
  text <- paste0("# Example: ", gsub("#.*$", "", text))  # Remove any existing comments and add new prefix
  text <- trimws(text)  # Trim any leading or trailing whitespace
  
  if (!is.null(text) && !is.null(query) && nchar(query) > 0) {
    new_entry <- data.frame(text = text, query = query, stringsAsFactors = FALSE)
    queries <- unique(rbind(queries, new_entry))  # Ensure no duplicates
    write.csv(queries, "References/saved_queries.csv", row.names = FALSE)
  } else {
    warning("Both text and query must have values. Skipping save.")
  }
}


# Function to get available records
get_available_records <- function(folder_path) {
  files <- list.files(folder_path, pattern = "my_duckdb_database-record-\\d+\\.duckdb$")
  as.numeric(gsub("my_duckdb_database-record-(\\d+)\\.duckdb", "\\1", files))
}

# Define UI
# Define UI
ui <- fluidPage(
  titlePanel("Text Query to SQL Generator"),
  sidebarLayout(
    sidebarPanel(
      radioButtons("fileSource", "Select File Source", choices = c("Pre-defined" = "predefined", "Select File" = "selectfile"), selected = "predefined"),
      conditionalPanel(
        condition = "input.fileSource == 'predefined'",
        selectInput("recordNumber", "Select Record Number", choices = get_available_records("."))
      ),
      conditionalPanel(
        condition = "input.fileSource == 'selectfile'",
        fileInput("filePath", "Choose DuckDB File", accept = c(".duckdb"))
      ),
      uiOutput("tableSelection"),
      uiOutput("columnSelection"),
      hr(),
      h4("Date Range"),
      verbatimTextOutput("dateInfo"),
      checkboxInput("addDateRange", "Specify Date Range", value = FALSE),
      conditionalPanel(
        condition = "input.addDateRange == true",
        dateInput("startDate", "Start Date", value = NULL),
        dateInput("endDate", "End Date", value = NULL)
      )
    ),
    mainPanel(
      fluidRow(
        column(2, radioButtons("queryType", "Select Query Type", choices = c("SQL Query" = "sql", "Natural Language Query" = "nl"))),
        column(8, textInput("inputQuery", "Enter your query...", width = '100%'))
      ),
      fluidRow(
        column(2),
        column(10, 
               tags$div(style = "display: flex; justify-content: flex-start; gap: 10px;",
                        actionButton("translateButton", "Translate", class = "btn-primary"),
                        actionButton("clearQueryButton", "Clear Query"),
                        actionButton("saveQueryButton", "Save Query")
               )
        )
      ),
      selectInput("exampleQueries", "Select an example query", choices = NULL, width = '100%'),
      verbatimTextOutput("outputSQL"),
      dataTableOutput("outputTable"),
      downloadButton("downloadLink", "Download Results from Query")
    )
  )
)


# Define server logic
server <- function(input, output, session) {
  values <- reactiveValues(data = NULL, tables = NULL, query = NULL)
  
  # Load saved queries on startup
  observe({
    updateSelectInput(session, "exampleQueries", choices = load_saved_queries()$text)
  })
  
  # Update record number dropdown based on available files
  observeEvent(input$fileSource, {
    updateSelectInput(session, "recordNumber", choices = get_available_records("."))
  }, ignoreInit = TRUE)
  
  # File path selection and Table Selection based on File Source
  observeEvent(input$fileSource, {
    db_path <- if (input$fileSource == "predefined" && !is.null(input$recordNumber)) {
      paste0("./my_duckdb_database-record-", input$recordNumber, ".duckdb")
    } else if (!is.null(input$filePath)) {
      input$filePath$datapath
    } else {
      return(NULL)
    }
    
    con <- dbConnect(duckdb::duckdb(), db_path)
    tables <- dbGetQuery(con, "SHOW TABLES")$name
    dbDisconnect(con)
    
    output$tableSelection <- renderUI({
      checkboxGroupInput("tableChecklist", "Select tables", choices = tables, inline = TRUE)
    })
    
    observeEvent(input$tableChecklist, {
      req(input$tableChecklist)
      
      columns_info <- lapply(input$tableChecklist, function(table) {
        con <- dbConnect(duckdb::duckdb(), db_path)
        columns <- dbGetQuery(con, paste0("PRAGMA table_info(", table, ")"))$name
        dbDisconnect(con)
        list(table = table, columns = columns)
      })
      
      output$columnSelection <- renderUI({
        fluidRow(
          lapply(columns_info, function(info) {
            column(4,
                   strong(info$table),
                   tags$ul(
                     lapply(info$columns, tags$li)
                   )
            )
          })
        )
      })
    })
    
    if (length(tables) > 0) {
      con <- dbConnect(duckdb::duckdb(), db_path)
      date_info <- dbGetQuery(con, "SELECT MIN(order_date) as earliest_date, MAX(order_date) as latest_date FROM orders")
      dbDisconnect(con)
      
      output$dateInfo <- renderText({
        paste("Earliest Date: ", date_info$earliest_date, "\nLatest Date: ", date_info$latest_date)
      })
    }
  })
  
  # Reset query input and examples when query type is changed
  observeEvent(input$queryType, {
    updateTextInput(session, "inputQuery", value = "")
    queries <- load_saved_queries()
    if (input$queryType == "sql") {
      updateSelectInput(session, "exampleQueries", choices = queries$query)
    } else {
      updateSelectInput(session, "exampleQueries", choices = queries$text)
    }
  })
  
  # Translation and Execution of Query
  observeEvent(input$translateButton, {
    req(input$inputQuery, input$tableChecklist)
    db_path <- if (input$fileSource == "predefined") {
      paste0("./my_duckdb_database-record-", input$recordNumber, ".duckdb")
    } else {
      input$filePath$datapath
    }
    
    query <- input$inputQuery
    tables <- paste(input$tableChecklist, collapse = ", ")
    
    if (input$queryType == "nl") {
      query <- generate_sql(query, tables)
    }
    
    if (input$addDateRange && !is.null(input$startDate) && !is.null(input$endDate)) {
      date_filter <- paste("WHERE signup_date BETWEEN '", input$startDate, "' AND '", input$endDate, "'", sep = "")
      query <- paste(query, date_filter)
    }
    
    con <- dbConnect(duckdb::duckdb(), db_path)
    result <- tryCatch({
      dbGetQuery(con, query)
    }, error = function(e) {
      data.frame(Error = "Error executing SQL query.")
    })
    dbDisconnect(con)
    
    values$data <- result
    values$query <- query  # Store the generated SQL query
    output$outputSQL <- renderText({
      paste("Generated SQL:", query)
    })
    output$outputTable <- renderDataTable({
      datatable(values$data)
    })
  })
  
  
  # Clear Query
  observeEvent(input$clearQueryButton, {
    updateTextInput(session, "inputQuery", value = "")
    values$data <- NULL
    output$outputSQL <- renderText({ "" })
    output$outputTable <- renderDataTable({ NULL })
    output$dateInfo <- renderText({ "" })
  })
  
  # Save Query
  observeEvent(input$saveQueryButton, {
    req(input$inputQuery)
    
    queries <- load_saved_queries()
    
    if (input$queryType == "sql") {
      new_entry <- data.frame(text = "", query = input$inputQuery, stringsAsFactors = FALSE)
      queries <- unique(rbind(queries, new_entry))  # Ensure no duplicates
    } else if (input$queryType == "nl") {
      req(values$query)
      
      if (!is.null(values$query) && !"Error" %in% colnames(values$data)) {
        new_entry <- data.frame(text = paste0("# Example: ", input$inputQuery), query = values$query, stringsAsFactors = FALSE)
        queries <- unique(rbind(queries, new_entry))  # Ensure no duplicates
      }
    }
    
    write.csv(queries, "saved_queries.csv", row.names = FALSE)
    
    # Update the example queries dropdown
    if (input$queryType == "sql") {
      updateSelectInput(session, "exampleQueries", choices = queries$query)
    } else {
      updateSelectInput(session, "exampleQueries", choices = queries$text)
    }
  })
  
  
  
  
  # Load Example Query
  observeEvent(input$exampleQueries, {
    selected_query <- if (input$queryType == "sql") {
      load_saved_queries()[load_saved_queries()$query == input$exampleQueries, "query"]
    } else {
      load_saved_queries()[load_saved_queries()$text == input$exampleQueries, "text"]
    }
    updateTextInput(session, "inputQuery", value = selected_query)
  })
  
  # Download Results
  output$downloadLink <- downloadHandler(
    filename = function() {
      # Capture the short description from the input query text
      short_description <- gsub("[^a-zA-Z0-9]", "_", substr(input$inputQuery, 1, 30))  # Truncate to 30 characters
      filename <- paste0("query_results_", short_description, "_", Sys.Date(), ".xlsx")
      
      # Ensure the filename does not exceed the maximum length
      if (nchar(filename) > 255) {  # Common maximum filename length
        filename <- paste0("query_results_", Sys.Date(), ".xlsx")
      }
      
      return(filename)
    },
    content = function(file) {
      if (!is.null(values$data)) {
        write.xlsx(values$data, file)
      }
    }
  )
}

# Run the application 
shinyApp(ui = ui, server = server)
