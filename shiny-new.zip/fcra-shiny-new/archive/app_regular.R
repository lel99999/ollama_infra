# Load necessary libraries
library(shiny)
library(DT)
library(duckdb)
library(openxlsx)
library(lubridate)  # For date handling

# Initialize few-shot examples
few_shot_examples <- data.frame(query = character())

# Load saved queries function
load_saved_queries <- function() {
  if (file.exists("saved_queries.csv")) {
    queries <- read.csv("saved_queries.csv")query 
    queries$query
  } else {
    NULL
  }
}

# Save new query function
save_query <- function(query) {
  queries <- load_saved_queries()
  if (!is.null(queries)) {
    queries <- c(queries, query)
    write.csv(data.frame(query = queries), "saved_queries.csv", row.names = FALSE)
  } else {
    write.csv(data.frame(query = query), "saved_queries.csv", row.names = FALSE)
  }
}

# Function to get available records
get_available_records <- function(folder_path) {
  files <- list.files(folder_path, pattern = "my_duckdb_database-record-\\d+\\.duckdb$")
  record_numbers <- as.numeric(gsub("my_duckdb_database-record-(\\d+)\\.duckdb", "\\1", files))
  sort(record_numbers)
}

# Define UI
ui <- fluidPage(
  titlePanel("Text Query to SQL Generator"),
  sidebarLayout(
    sidebarPanel(
      radioButtons("fileSource", "Select File Source", choices = c("Pre-defined" = "predefined", "Select File" = "selectfile"), selected = "predefined"),
      conditionalPanel(
        condition = "input.fileSource == 'predefined'",
        selectInput("recordNumber", "Select Record Number", choices = get_available_records("."))
      ),
      conditionalPanel(
        condition = "input.fileSource == 'selectfile'",
        fileInput("filePath", "Choose DuckDB File", accept = c(".duckdb"))
      ),
      uiOutput("tableSelection"),
      uiOutput("columnSelection"),
      textInput("inputQuery", "Enter your query..."),
      selectInput("exampleQueries", "Select an example query", choices = load_saved_queries()),
      hr(),
      h4("Date Range"),
      verbatimTextOutput("dateInfo"),
      checkboxInput("addDateRange", "Specify Date Range", value = FALSE),
      conditionalPanel(
        condition = "input.addDateRange == true",
        dateInput("startDate", "Start Date", value = NULL),
        dateInput("endDate", "End Date", value = NULL)
      ),
      actionButton("translateButton", "Translate", class = "btn-primary"),
      actionButton("clearQueryButton", "Clear Query"),
      actionButton("saveQueryButton", "Save Query")
    ),
    mainPanel(
      verbatimTextOutput("outputSQL"),
      dataTableOutput("outputTable"),
      downloadButton("downloadLink", "Download Results from Query")
    )
  )
)

# Define server logic
server <- function(input, output, session) {
  values <- reactiveValues(data = NULL, tables = NULL, columns = NULL, query = NULL)
  
  # Load saved queries on startup
  observe({
    updateSelectInput(session, "exampleQueries", choices = load_saved_queries())
  })
  
  # Update record number dropdown based on available files
  observe({
    available_records <- get_available_records(".")
    updateSelectInput(session, "recordNumber", choices = available_records)
  })
  
  # File path selection and Table Selection based on File Source
  observeEvent(input$fileSource, {
    if (input$fileSource == "predefined") {
      req(input$recordNumber)
      db_path <- paste0("./my_duckdb_database-record-", input$recordNumber, ".duckdb")
    } else {
      req(input$filePath)
      db_path <- input$filePath$datapath
    }
    
    con <- dbConnect(duckdb::duckdb(), db_path)
    values$tables <- dbGetQuery(con, "SHOW TABLES")$name
    dbDisconnect(con)
    output$tableSelection <- renderUI({
      checkboxGroupInput("tableChecklist", "Select tables", choices = values$tables, selected = NULL)
    })
    
    # Provide earliest and latest date information
    con <- dbConnect(duckdb::duckdb(), db_path)
    date_info <- dbGetQuery(con, "SELECT MIN(order_date) as earliest_date, MAX(order_date) as latest_date FROM orders")
    dbDisconnect(con)
    
    output$dateInfo <- renderText({
      paste("Earliest Date: ", date_info$earliest_date, "\nLatest Date: ", date_info$latest_date)
    })
  })
  
  # Column Selection based on Table Selection
  observeEvent(input$tableChecklist, {
    req(input$tableChecklist)
    db_path <- if (input$fileSource == "predefined") {
      paste0("./my_duckdb_database-record-", input$recordNumber, ".duckdb")
    } else {
      input$filePath$datapath
    }
    con <- dbConnect(duckdb::duckdb(), db_path)
    columns_info <- ""
    for (table in input$tableChecklist) {
      columns <- dbGetQuery(con, paste0("PRAGMA table_info(", table, ")"))
      columns_info <- paste(columns_info, "Columns in", table, ":", paste(columns$name, collapse = ", "), "\n")
    }
    dbDisconnect(con)
    output$columnSelection <- renderUI({
      verbatimTextOutput("columnInfo")
    })
    output$columnInfo <- renderText({
      columns_info
    })
  })
  
  # Translation and Execution of Query
  observeEvent(input$translateButton, {
    req(input$inputQuery, input$tableChecklist)
    db_path <- if (input$fileSource == "predefined") {
      paste0("./my_duckdb_database-record-", input$recordNumber, ".duckdb")
    } else {
      input$filePath$datapath
    }
    con <- dbConnect(duckdb::duckdb(), db_path)
    sql_query <- input$inputQuery
    
    # Apply date filter if specified
    if (input$addDateRange) {
      if (!is.null(input$startDate) && !is.null(input$endDate)) {
        date_filter <- paste("WHERE signup_date BETWEEN '", input$startDate, "' AND '", input$endDate, "'", sep = "")
        sql_query <- paste(sql_query, date_filter)
      }
    }
    
    result <- tryCatch({
      dbGetQuery(con, sql_query)
    }, error = function(e) {
      data.frame(Error = "Error executing SQL query.")
    })
    dbDisconnect(con)
    
    # Add successful query to few-shot examples
    if (!"Error" %in% colnames(result)) {
      few_shot_examples <<- rbind(few_shot_examples, data.frame(query = sql_query))
    }
    
    values$data <- result
    output$outputSQL <- renderText({
      paste("Generated SQL:", sql_query)
    })
    output$outputTable <- renderDataTable({
      datatable(values$data)
    })
  })
  
  # Clear Query
  observeEvent(input$clearQueryButton, {
    updateTextInput(session, "inputQuery", value = "")
    values$data <- NULL
    output$outputSQL <- renderText({ "" })
    output$outputTable <- renderDataTable({ NULL })
    output$dateInfo <- renderText({ "" })
  })
  
  # Save Query
  observeEvent(input$saveQueryButton, {
    if (!is.null(input$inputQuery) && nzchar(input$inputQuery)) {
      save_query(input$inputQuery)
      updateSelectInput(session, "exampleQueries", choices = load_saved_queries())
    }
  })
  
  # Load Example Query
  observeEvent(input$exampleQueries, {
    updateTextInput(session, "inputQuery", value = input$exampleQueries)
  })
  
  # Download Results
  output$downloadLink <- downloadHandler(
    filename = function() {
      paste0("query_results_", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      if (!is.null(values$data)) {
        write.xlsx(values$data, file)
      }
    }
  )
}

# Run the application 
shinyApp(ui = ui, server = server)
