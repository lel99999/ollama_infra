# fcra-shiny-new
The purpose of this App is to query duckdb data tables using natural language. This is a template App that can be adapted to the specific use case.
