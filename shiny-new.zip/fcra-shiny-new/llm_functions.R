library(ollamar)
library(mall)
library(dplyr)
library(tidyr)
ollamar::pull("codellama",host="http://10.95.79.62:11434") # do once
mall::llm_use("ollama", "codellama", seed = 100, temperature = 0)



# Load saved queries as few shot examples
load_examples <- function() {
  if (file.exists("saved_queries.csv")) {
    queries <- read.csv("saved_queries.csv")
    queries <- queries %>% filter(!is.na(text)) %>%
      unite("example", c('text','query'), sep = " translates to \n") %>%
      select(example)
    return(queries)
  }
}

examples <- load_examples()

generate_sql <- function(query, table_names) {
  prompt <- paste0("Considering these examples", examples, "\nTranslate the following English query into SQL but do not explain the reasoning", table_names, ":", query, "\nSQL:")
  response = mall::llm_vec_translate(prompt, "SQL")
  
  if (grepl("```", response)) {
    result <- strsplit(response, "```")[[1]][2]
  } else { # Sometimes the LLM just provides an explanation that needs to be removed
    result <- sub("^.*:", "", response) 
    result <- sub(";.*$", ";", result)
  }
  
  return(trimws(result))
}
